const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const fileInput=$("#fileInput"), drop=$("#dropZone"), workspace=$("#workspace");
let file=null, kind="", selectedFormat="", ffmpeg=null, compressQ=55, objectUrl=null, threeTaskId=null, threeTimer=null;

function device(){const ua=navigator.userAgent.toLowerCase();const d=/iphone|ipad|ipod/.test(ua)?"iPhone / iPad":/android/.test(ua)?"Android":/mac/.test(ua)?"Mac":/windows/.test(ua)?"Windows PC":/linux/.test(ua)?"Linux":"جهاز";$("#deviceName").textContent=d}
device();

async function health(){try{const r=await fetch('/api/health',{cache:'no-store'});const d=await r.json();$("#apiState").textContent=d.meshyConfigured?'AI 3D جاهز':'AI 3D يحتاج مفتاح';$("#apiState").parentElement.querySelector('i').style.background=d.meshyConfigured?'#48e4a1':'#ffc857'}catch{$("#apiState").textContent='وضع محلي'}}
health();

$("#pickBtn").onclick=()=>fileInput.click();
$("#quick3d").onclick=()=>{workspace.classList.remove('hidden');switchTab('model3d');document.querySelector('#model3dPanel').scrollIntoView({behavior:'smooth',block:'center'})};
$("#quickMedia").onclick=()=>{drop.scrollIntoView({behavior:'smooth',block:'center'});fileInput.click()};
fileInput.onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
['dragenter','dragover'].forEach(x=>drop.addEventListener(x,e=>{e.preventDefault();drop.classList.add('drag')}));
['dragleave','drop'].forEach(x=>drop.addEventListener(x,e=>{e.preventDefault();drop.classList.remove('drag')}));
drop.addEventListener('drop',e=>e.dataTransfer.files[0]&&loadFile(e.dataTransfer.files[0]));

function loadFile(f){
 file=f; if(objectUrl)URL.revokeObjectURL(objectUrl); objectUrl=URL.createObjectURL(f);
 kind=f.type.startsWith('video/')?'video':(f.type==='image/gif'||f.name.toLowerCase().endsWith('.gif'))?'gif':f.type.startsWith('image/')?'image':'other';
 if(kind==='other'){alert('اختار صورة أو فيديو أو GIF.');return}
 workspace.classList.remove('hidden'); $("#fileName").textContent=f.name; $("#fileMeta").textContent=`${(f.size/1024/1024).toFixed(2)} MB • ${f.type||'unknown'}`;
 const ip=$("#imgPreview"),vp=$("#videoPreview"); ip.classList.add('hidden');vp.classList.add('hidden');
 if(kind==='image'||kind==='gif'){ip.src=objectUrl;ip.classList.remove('hidden')}else{vp.src=objectUrl;vp.classList.remove('hidden')}
 buildFormats();setupEdit();
 if(kind==='image')switchTab('model3d');else switchTab('convert');
 workspace.scrollIntoView({behavior:'smooth',block:'start'});
}
function buildFormats(){const formats=kind==='image'?['JPG','PNG','WEBP','AVIF','GIF']:['MP4','WEBM','MOV','AVI','MKV','GIF','MP3'];const grid=$("#formatGrid");grid.innerHTML='';formats.forEach((x,i)=>{const b=document.createElement('button');b.className='format'+(i===0?' selected':'');b.textContent=x;b.onclick=()=>{$$('.format').forEach(q=>q.classList.remove('selected'));b.classList.add('selected');selectedFormat=x};grid.appendChild(b)});selectedFormat=formats[0]}
function setupEdit(){
 $("#videoTrim").classList.toggle('hidden',!(kind==='video'||kind==='gif'));$("#imageCrop").classList.toggle('hidden',kind!=='image');
 if(kind==='image'){const im=$("#imgPreview");im.onload=()=>{$("#cropW").value=im.naturalWidth;$("#cropH").value=im.naturalHeight}}
 else{const v=$("#videoPreview");v.onloadedmetadata=()=>{const d=Number(v.duration)||0;$("#endTime").value=d.toFixed(1);$("#mediaDuration").value=d;$("#durationLabel").textContent=formatTime(d);['rangeStart','rangeEnd'].forEach(id=>$("#"+id).max=d);$("#rangeEnd").value=d;$("#removeEnd").value=d.toFixed(1)}}
}
function formatTime(s){s=Math.max(0,Number(s)||0);return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')}
function syncTimeline(){const s=+$("#rangeStart").value,e=+$("#rangeEnd").value;$("#startTime").value=s.toFixed(1);$("#endTime").value=e.toFixed(1);$("#removeEnd").value=e.toFixed(1)}
document.addEventListener('input',e=>{if(e.target.id==='rangeStart'||e.target.id==='rangeEnd'){if(+$("#rangeStart").value>+$("#rangeEnd").value){if(e.target.id==='rangeStart')$("#rangeEnd").value=e.target.value;else $("#rangeStart").value=e.target.value}syncTimeline()}});
function switchTab(name){$$('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));['convert','edit','compress','model3d'].forEach(p=>$("#"+p+'Panel').classList.toggle('hidden',p!==name))}
$$('.tab').forEach(t=>t.onclick=()=>switchTab(t.dataset.tab));
$("#quality").oninput=e=>$("#qualityVal").textContent=e.target.value+'%';
$$('.compress-options button').forEach(b=>b.onclick=()=>{$$('.compress-options button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');compressQ=+b.dataset.q});
$("#removeBtn").onclick=()=>{file=null;if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=null;workspace.classList.add('hidden');fileInput.value='';threeTaskId=null;clearTimeout(threeTimer)};
function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1500)}
function ext(name){return name.split('.').pop().toLowerCase()}
async function imageProcess(output,quality=.85,crop=false){const im=new Image();im.src=objectUrl;await im.decode();let sx=0,sy=0,sw=im.naturalWidth,sh=im.naturalHeight;if(crop){sx=+$("#cropX").value;sy=+$("#cropY").value;sw=+$("#cropW").value;sh=+$("#cropH").value;if(sx<0||sy<0||sw<=0||sh<=0||sx+sw>im.naturalWidth||sy+sh>im.naturalHeight)throw Error('أبعاد القص خارج الصورة')}const c=document.createElement('canvas');c.width=sw;c.height=sh;c.getContext('2d').drawImage(im,sx,sy,sw,sh,0,0,sw,sh);const mime={JPG:'image/jpeg',PNG:'image/png',WEBP:'image/webp',AVIF:'image/avif'}[output]||'image/webp';return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(Error('الصيغة غير مدعومة في هذا المتصفح')),mime,quality))}
async function ensureFF(){if(ffmpeg)return ffmpeg;if(!window.FFmpeg?.createFFmpeg)throw Error('محرك الفيديو غير متوفر');ffmpeg=window.FFmpeg.createFFmpeg({log:false,corePath:'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.11.6/dist/ffmpeg-core.js'});await ffmpeg.load();return ffmpeg}
async function fetchFile(f){return new Uint8Array(await f.arrayBuffer())}
function setConvertStatus(t){$("#convertStatus").textContent=t}
async function videoConvert(output,compress=false,trim=false){
 const f=await ensureFF(),input='input.'+ext(file.name),q=compress?compressQ:+$("#quality").value;
 try{f.FS('unlink',input)}catch{}
 f.FS('writeFile',input,await fetchFile(file));
 let args=['-i',input];
 if(trim){
  const s=Math.max(0,+$("#startTime").value||0),e=Math.max(s,+$("#endTime").value||0);
  if(e<=s)throw Error('وقت القص غير صحيح');
  args=['-ss',String(s),'-t',String(e-s),'-i',input];
 }
 const out='output.'+output.toLowerCase();
 const crf=Math.round(46-q/2);
 if(output==='MP4')args=args.concat(['-c:v','libx264','-preset','veryfast','-crf',String(crf),'-c:a','aac','-movflags','+faststart','-y',out]);
 else if(output==='WEBM')args=args.concat(['-c:v','libvpx-vp9','-crf',String(Math.max(20,Math.round(55-q/2))),'-b:v','0','-c:a','libopus','-y',out]);
 else if(output==='MOV')args=args.concat(['-c:v','libx264','-preset','veryfast','-crf',String(crf),'-c:a','aac','-y',out]);
 else if(output==='MKV')args=args.concat(['-c:v','libx264','-preset','veryfast','-crf',String(crf),'-c:a','aac','-y',out]);
 else if(output==='AVI')args=args.concat(['-c:v','mpeg4','-q:v',String(Math.max(2,Math.round(8-(q/20)))),'-c:a','libmp3lame','-b:a','128k','-y',out]);
 else if(output==='GIF')args=args.concat(['-vf',"fps=12,scale='min(720,iw)':-1:flags=lanczos",'-an','-y',out]);
 else if(output==='MP3')args=args.concat(['-vn','-c:a','libmp3lame','-b:a',Math.max(48,q)+'k','-y',out]);
 else throw Error('الصيغة غير مدعومة');
 await f.run(...args);
 const data=f.FS('readFile',out);
 const type={GIF:'image/gif',MP3:'audio/mpeg',WEBM:'video/webm',MOV:'video/quicktime',AVI:'video/x-msvideo',MKV:'video/x-matroska',MP4:'video/mp4'}[output]||'application/octet-stream';
 return new Blob([data.buffer],{type});
}

async function imageToGif(){
 const f=await ensureFF();
 const png=await imageProcess('PNG',1,false);
 const input='zoro-image.png', out='zoro-image.gif';
 try{f.FS('unlink',input)}catch{}
 try{f.FS('unlink',out)}catch{}
 f.FS('writeFile',input,new Uint8Array(await png.arrayBuffer()));
 await f.run('-i',input,'-vf',"fps=1,scale='min(1600,iw)':-1:flags=lanczos",'-loop','0','-y',out);
 const data=f.FS('readFile',out);
 return new Blob([data.buffer],{type:'image/gif'});
}

$("#convertBtn").onclick=async()=>{
 if(!file)return; const btn=$("#convertBtn");btn.disabled=true;btn.textContent='جاري التحويل...';setConvertStatus('جاري تجهيز التحويل...');
 try{
  let b;
  if(kind==='image'){
   b=selectedFormat==='GIF'?await imageToGif():await imageProcess(selectedFormat,+$("#quality").value/100,false);
  }else{
   b=await videoConvert(selectedFormat,false,false);
  }
  download(b,`${file.name.replace(/\.[^.]+$/,'')}.${selectedFormat.toLowerCase()}`);
  setConvertStatus('تم التحويل والتنزيل بنجاح ✅');
 }catch(e){
  console.error(e);
  const msg=e?.message||'خطأ غير معروف';
  setConvertStatus('فشل التحويل: '+msg);
  alert('تعذر التحويل: '+msg);
 }finally{btn.disabled=false;btn.textContent='تحويل وتنزيل'}
};

$("#cutOutBtn").onclick=async()=>{if(!file||(kind!=='video'&&kind!=='gif'))return;const btn=$("#cutOutBtn");btn.disabled=true;btn.textContent='جاري حذف المشهد...';try{const s=+$("#removeStart").value||0,e=+$("#removeEnd").value||0,d=+$("#mediaDuration").value||0;if(s<0||e<=s||e>d)throw Error('حدد وقت صحيح');const f=await ensureFF(),input='input.'+ext(file.name);try{f.FS('unlink',input)}catch{}
 f.FS('writeFile',input,await fetchFile(file));const output=kind==='gif'?'GIF':'MP4',out='output.'+output.toLowerCase();const filter=`[0:v]trim=0:${s},setpts=PTS-STARTPTS[a];[0:v]trim=start=${e},setpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=1:a=0[v]`;if(output==='GIF')await f.run('-i',input,'-filter_complex',filter,'-map','[v]','-vf',"fps=12,scale='min(720,iw)':-1:flags=lanczos",'-y',out);else await f.run('-i',input,'-filter_complex',filter,'-map','[v]','-c:v','libx264','-preset','veryfast','-crf','23','-an','-y',out);const data=f.FS('readFile',out);download(new Blob([data.buffer],{type:output==='GIF'?'image/gif':'video/mp4'}),`${file.name.replace(/\.[^.]+$/,'')}-scene-removed.${output.toLowerCase()}`)}catch(err){alert('تعذر حذف المشهد: '+(err.message||'تأكد من الأوقات والملف.'));console.error(err)}finally{btn.disabled=false;btn.textContent='حذف المشهد وتنزيل الباقي'}};

$("#applyEditBtn").onclick=async()=>{if(!file)return;const btn=$("#applyEditBtn");btn.disabled=true;btn.textContent='جاري القص...';try{if(kind==='image'){const b=await imageProcess('WEBP',.9,true);download(b,`${file.name.replace(/\.[^.]+$/,'')}-crop.webp`)}else{const b=await videoConvert(kind==='gif'?'GIF':'MP4',false,true);download(b,`${file.name.replace(/\.[^.]+$/,'')}-cut.${kind==='gif'?'gif':'mp4'}`)}}catch(e){alert('تعذر القص: '+(e.message||'تأكد من الأوقات والملف.'));console.error(e)}finally{btn.disabled=false;btn.textContent='تطبيق القص وتنزيل'}};

$("#compressBtn").onclick=async()=>{if(!file)return;const btn=$("#compressBtn");btn.disabled=true;btn.textContent='جاري الضغط...';$("#progressBar").style.width='20%';try{let b,name;if(kind==='image'){b=await imageProcess('WEBP',compressQ/100);name=`${file.name.replace(/\.[^.]+$/,'')}-compressed.webp`}else{$("#progressBar").style.width='45%';b=await videoConvert('MP4',true);name=`${file.name.replace(/\.[^.]+$/,'')}-compressed.mp4`}$("#progressBar").style.width='100%';$("#status").textContent='تم الضغط والتنزيل بنجاح ✅';download(b,name)}catch(e){alert('تعذر الضغط: '+(e.message||'حاول مرة ثانية.'));console.error(e)}finally{btn.disabled=false;btn.textContent='ضغط وتنزيل'}};

function set3DStatus(text,progress){$("#threeStatus").textContent=text;if(Number.isFinite(progress))$("#threeProgress").style.width=Math.max(0,Math.min(100,progress))+'%'}
$("#threeQuality").onchange=e=>{$("#threeQualityNote").textContent=e.target.value==='standard'?'القياسي أسرع ومناسب للتجربة.':e.target.value==='high'?'العالي يعطي تفاصيل أكثر لكنه يحتاج وقتاً وموارد أكثر.':'Ultra يعطي أعلى دقة هندسية/خامة ويحتاج وقتاً وموارد أكثر.'};
async function prepare3DImage(inputFile){if(/^image\/(jpeg|png)$/.test(inputFile.type)&&inputFile.size<=10*1024*1024)return inputFile;const img=new Image();img.src=URL.createObjectURL(inputFile);await img.decode();const max=2048,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(img.src);return await new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(new File([b],'zoro-input.png',{type:'image/png'})):reject(Error('تعذر تجهيز الصورة')),'image/png'))}
async function create3DTask(){
 if(!file||kind!=='image'){alert('للـ3D اختار صورة JPG أو PNG، مو GIF.');return}
 const btn=$("#make3dBtn");btn.disabled=true;btn.textContent='🧊 جاري بناء المجسم...';$("#viewerCard").classList.add('hidden');set3DStatus('جاري تجهيز الصورة ورفعها بأمان إلى خدمة 3D...',8);
 try{const prepared=await prepare3DImage(file),form=new FormData();form.append('image',prepared);form.append('quality',$("#threeQuality").value);form.append('format',$("#threeFormat").value);const r=await fetch('/api/3d/create',{method:'POST',body:form,cache:'no-store'});const data=await r.json().catch(()=>({}));if(!r.ok)throw Error(data.error||`HTTP ${r.status}`);if(!data.result)throw Error('السيرفر لم يرجع رقم المهمة');threeTaskId=data.result;set3DStatus('تم استلام الصورة. الذكاء الاصطناعي يبني المجسم الآن...',15);poll3D()}catch(e){console.error(e);set3DStatus('تعذر بدء تحويل 3D: '+(e.message||'خطأ غير معروف'),0);btn.disabled=false;btn.textContent='🧊 إنشاء المجسم 3D'}}
async function poll3D(){clearTimeout(threeTimer);try{const r=await fetch('/api/3d/status?id='+encodeURIComponent(threeTaskId),{cache:'no-store'}),data=await r.json().catch(()=>({}));if(!r.ok)throw Error(data.error||`HTTP ${r.status}`);const progress=Number(data.progress||0);if(data.status==='SUCCEEDED'){set3DStatus('اكتمل المجسم بنجاح. تقدر تشوفه وتنزله هسه 🎉',100);show3DResult(data);const btn=$("#make3dBtn");btn.disabled=false;btn.textContent='🧊 إنشاء مجسم جديد';return}if(data.status==='FAILED'||data.status==='CANCELED')throw Error(data.task_error?.message||data.error?.message||'فشل إنشاء المجسم');set3DStatus(`جاري بناء المجسم... ${progress}%`,Math.max(15,progress));threeTimer=setTimeout(poll3D,4000)}catch(e){console.error(e);set3DStatus('صار خطأ أثناء إنشاء المجسم: '+(e.message||'حاول مرة ثانية'),0);const btn=$("#make3dBtn");btn.disabled=false;btn.textContent='🧊 إنشاء المجسم 3D'}}
function show3DResult(data){const card=$("#viewerCard"),viewer=$("#modelViewer"),urls=data.model_urls||{};if(!urls.glb)throw Error('لم يرجع السيرفر ملف GLB للعرض');viewer.src=urls.glb;viewer.poster=data.thumbnail_url||'';card.classList.remove('hidden');const chosen=$("#threeFormat").value||'glb',main=$("#download3d"),mainUrl=urls[chosen]||urls.glb;main.href=mainUrl;main.textContent='⬇️ تنزيل '+(urls[chosen]?chosen:'glb').toUpperCase();const box=$("#formatDownloads");box.innerHTML='';['glb','obj','fbx','stl','usdz','3mf'].forEach(fmt=>{if(urls[fmt]){const a=document.createElement('a');a.href=urls[fmt];a.target='_blank';a.rel='noopener';a.download='';a.textContent='⬇️ '+fmt.toUpperCase();box.appendChild(a)}});card.scrollIntoView({behavior:'smooth',block:'center'})}
$("#make3dBtn").onclick=create3DTask;
$("#reset3d").onclick=()=>{const v=$("#modelViewer");if(v&&v.resetTurntableRotation)v.resetTurntableRotation();if(v){v.cameraOrbit='0deg 75deg auto';v.fieldOfView='45deg'}};
$("#threeFormat").onchange=e=>{const chosen=e.target.value,links=[...$("#formatDownloads").querySelectorAll('a')],found=links.find(a=>a.textContent.toLowerCase().includes(chosen));if(found){$("#download3d").href=found.href;$("#download3d").textContent='⬇️ تنزيل '+chosen.toUpperCase()}};
