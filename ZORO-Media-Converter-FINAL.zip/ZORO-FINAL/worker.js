const MESHY_API = 'https://api.meshy.ai/openapi/v1';

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'access-control-allow-headers': 'Content-Type, Authorization',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      ...CORS,
    },
  });
}

function parseJson(text) {
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

function upstreamError(body, status) {
  const message = body?.message || body?.error?.message || body?.error || body?.detail;
  if (message) return String(message);
  if (status === 401) return 'مفتاح Meshy غير صحيح.';
  if (status === 402) return 'رصيد Meshy غير كافٍ لإنشاء المجسم.';
  if (status === 429) return 'تم تجاوز حد الطلبات. انتظر قليلاً ثم جرّب مرة ثانية.';
  return `خدمة 3D رجعت HTTP ${status}.`;
}

async function imageToDataUri(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return `data:${file.type};base64,${btoa(binary)}`;
}

async function create3D(request, env) {
  if (!env.MESHY_API_KEY) {
    return json({ error: 'MESHY_API_KEY غير مضبوط على Cloudflare Worker.' }, 500);
  }

  const form = await request.formData();
  const image = form.get('image');
  if (!(image instanceof File)) return json({ error: 'الصورة غير موجودة.' }, 400);
  if (image.size > 15 * 1024 * 1024) return json({ error: 'حجم الصورة كبير جداً. الحد 15MB.' }, 413);

  const allowed = ['image/jpeg', 'image/png'];
  if (!allowed.includes(image.type)) {
    return json({ error: 'استخدم JPG أو PNG للتحويل إلى 3D.' }, 415);
  }

  const quality = ['standard', 'high', 'ultra'].includes(form.get('quality')) ? form.get('quality') : 'high';
  const requested = String(form.get('format') || 'glb').toLowerCase();
  const target = ['glb', 'obj', 'fbx', 'stl', 'usdz', '3mf'].includes(requested) ? requested : 'glb';

  const payload = {
    image_url: await imageToDataUri(image),
    model_type: 'standard',
    ai_model: 'meshy-7.1',
    image_enhancement: true,
    should_texture: true,
    enable_pbr: true,
    target_formats: Array.from(new Set(['glb', target])),
  };

  if (quality === 'high') payload.geometry_resolution = '2k';
  if (quality === 'ultra') {
    payload.geometry_resolution = '4k';
    payload.should_remesh = true;
    payload.target_polycount = 100000;
  }

  const upstream = await fetch(`${MESHY_API}/image-to-3d`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.MESHY_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const text = await upstream.text();
  const body = parseJson(text);
  if (!upstream.ok) return json({ error: upstreamError(body, upstream.status), upstream: body }, upstream.status);
  return json(body, upstream.status);
}

async function status3D(env, id) {
  if (!env.MESHY_API_KEY) return json({ error: 'MESHY_API_KEY غير مضبوط على Cloudflare Worker.' }, 500);
  if (!id || !/^[A-Za-z0-9-]{8,100}$/.test(id)) return json({ error: 'معرّف مهمة 3D غير صحيح.' }, 400);

  const upstream = await fetch(`${MESHY_API}/image-to-3d/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${env.MESHY_API_KEY}` },
  });
  const text = await upstream.text();
  const body = parseJson(text);
  if (!upstream.ok) return json({ error: upstreamError(body, upstream.status), upstream: body }, upstream.status);
  return json(body, upstream.status);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    try {
      if (url.pathname === '/api/health' && request.method === 'GET') {
        return json({ ok: true, service: 'ZORO', ai3d: true, meshyConfigured: !!env.MESHY_API_KEY });
      }
      if (url.pathname === '/api/3d/create' && request.method === 'POST') {
        return await create3D(request, env);
      }
      if (url.pathname === '/api/3d/status' && request.method === 'GET') {
        return await status3D(env, url.searchParams.get('id'));
      }
      return env.ASSETS.fetch(request);
    } catch (error) {
      return json({ error: error?.message || 'خطأ غير متوقع في السيرفر.' }, 500);
    }
  },
};
