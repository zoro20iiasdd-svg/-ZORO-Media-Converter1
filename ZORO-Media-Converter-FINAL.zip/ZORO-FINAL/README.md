# ZORO — FINAL

نسخة نهائية مرتبة من ZORO تجمع موقع التحويل القديم مع AI 3D في مشروع Cloudflare Worker واحد.

## الموجود
- واجهة ZORO RTL للموبايل والكمبيوتر.
- تحويل الصور: JPG / PNG / WEBP / AVIF / GIF.
- تحويل الفيديو: MP4 / WEBM / MOV / AVI / MKV / GIF / MP3.
- قص الصور.
- قص بداية/نهاية الفيديو وGIF.
- حذف مشهد من وسط الفيديو/ GIF ودمج الباقي.
- ضغط الصور والفيديو.
- تحويل الصورة إلى 3D عبر Meshy مع GLB للعرض وصيغ أخرى عند توفرها.
- عارض 3D قابل للتدوير والتكبير والتحكم.
- API key محفوظ داخل Cloudflare Worker Secret وليس داخل الصفحة.
- `/api/health` لفحص إعداد AI 3D.

## النشر على Cloudflare
من داخل مجلد المشروع:

```bash
npx wrangler login
npx wrangler secret put MESHY_API_KEY
npx wrangler deploy
```

ضع مفتاح Meshy عندما يطلبه Wrangler. بعد نجاح النشر سيعطيك Cloudflare رابط `workers.dev`.

## ملاحظة مهمة
Cloudflare ينشر Worker والملفات الموجودة في `public` كوحدة واحدة. مسارات `/api/*` تذهب إلى Worker، وبقية الموقع تأتي من `public`.

تحويل الوسائط يتم داخل المتصفح باستخدام FFmpeg.wasm، لذلك الملفات الكبيرة قد تكون أبطأ على الهاتف. AI 3D يحتاج مفتاح Meshy صالحاً ورصيداً/صلاحية مناسبة لدى Meshy.
